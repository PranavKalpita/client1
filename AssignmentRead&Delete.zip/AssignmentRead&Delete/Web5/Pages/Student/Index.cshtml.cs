using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using System.Data.SqlClient;

namespace Web5.Pages.Student
{
    public class IndexModel : PageModel
    {
        private readonly IConfiguration _configuration;  // Dependency Injection to get config
        public List<StudentInfo> listStudents = new List<StudentInfo>();

        public IndexModel(IConfiguration configuration)
        {
            _configuration = configuration;
        }

        public void OnGet()
        {
            try
            {
                // Fetch the connection string from appsettings.json
                string connectionString = _configuration.GetConnectionString("DefaultConnection");

                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    connection.Open();
                    string sql = "SELECT * FROM students";  // Changed to 'students'
                    using (SqlCommand command = new SqlCommand(sql, connection))
                    {
                        using (SqlDataReader reader = command.ExecuteReader())
                        {
                            while (reader.Read())
                            {
                                StudentInfo studentInfo = new StudentInfo();  // Changed to 'StudentInfo'
                                studentInfo.id = "" + reader.GetInt32(0);
                                studentInfo.name = reader.GetString(1);
                                studentInfo.email = reader.GetString(2);
                                studentInfo.phone = reader.GetString(3);
                                studentInfo.address = reader.GetString(4);
                                studentInfo.created_at = reader.GetDateTime(5).ToString();

                                listStudents.Add(studentInfo);  // Changed to 'listStudents'
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("Exception: " + ex.ToString());
            }
        }

        public class StudentInfo  // Changed to 'StudentInfo'
        {
            public string id;  // Use 'string' instead of 'String' for consistency
            public string name;
            public string email;
            public string phone;
            public string address;
            public string created_at;
        }
    }
}
